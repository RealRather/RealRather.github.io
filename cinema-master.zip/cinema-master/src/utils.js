const SortType = {
  DISTANCE: `distance`,
  TITLE: `title`
};

export default SortType;
