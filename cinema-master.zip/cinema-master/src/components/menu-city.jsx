import React, {Component} from 'react';

class MenuCity extends Component {
  constructor(props) {
    super(props);

    this.state = {
      cityId: ``
    };

    this.setCityValue = this.setCityValue.bind(this);
  }

  setCityValue(evt) {
    this.setState({
      cityId: evt.target.value
    });
  }

  render() {
    const {
      handleMouseDown,
      handleSelectChange,
      cities
    } = this.props;

    if (this.state.cityId) {
      handleSelectChange();
    }

    return(
      <div className="cities">
        <h2 className="cities__label">Выберите город</h2>
        <select id="cities"
                onChange = {this.setCityValue}
                onMouseDown={handleMouseDown}
                className="cities__select" >
          <option className="cities__item"/>
          {cities.map((city) => <option
            key={city.id}
            className="cities__item"
            alias={city.attributes.alias}
            value={city.id}
          >
            {city.attributes.name}
          </option>)}
        </select>
      </div>
    )
  }
}

export default MenuCity;
