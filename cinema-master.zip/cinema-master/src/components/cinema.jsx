import React, {Component} from 'react';

class Cinema extends Component {
  render() {
    const {attributes, id} = this.props;
    const labels = attributes.labels.filter((label) => label.type === `text`);

    return (
      <div
        key={id}
        className="cinemas__item"
      >
        <div className="cinema">
          <div className="cinema__title">{attributes.shortTitle ? attributes.shortTitle : attributes.title}</div>
          <div className="cinema__address">{attributes.mall ? attributes.mall : attributes.address}</div>
          {attributes.subway.length > 0
            ? <div className="cinema__subway">
              {attributes.subway.map(({color, distance, name: subwayName, id: subwayId}) =>
                <div
                    key={`${subwayName}-${subwayId}`}
                    id={subwayId}
                    distance = {distance}
                    className="subway"
                  >
                  <span className="subway__name">{subwayName}</span>
                  <span
                    className="subway__color"
                    style={{
                      color: `#${color}`,
                    }}/>
                </div>
              )}
          </div>
            : ``}
        </div>
        <div className="labels">
          {labels.length > 0
            ? <p className="labels__text">{labels[0].text}</p>
            : ``
          }
          <div className="labels__favorite">
            <button className="labels__favorite-btn" type="button">+</button>
          </div>
        </div>
      </div>
    )
  }
}

export default Cinema;
