import React, {Component} from 'react';
import SortType from '../utils.js';

class Sort extends Component{
  render() {
    const {
      sortType,
      isSelectedCIty,
      handleSortChange
    } = this.props;

    if (isSelectedCIty) {
      return(
          <div className="sort">
            <div className="sort__item">
              <input id={`sort-${SortType.TITLE}`}
                     className="sort__input  visually-hidden"
                     type="radio"
                     name="sort"
                     value={SortType.TITLE}
                     onChange={()=>{}}
                     checked ={sortType === SortType.TITLE ? `checked` : ``}
              />
              <label
                onMouseDown = {handleSortChange}
                className="sort__btn  sort__btn--active"
                htmlFor={`sort-${SortType.TITLE}`}
                id={SortType.TITLE}
              >
                По заголовку
              </label>
            </div>

            <div className="sort__item">
              <input id={`sort-${SortType.DISTANCE}`}
                     className="sort__input  visually-hidden"
                     type="radio" name="sort"
                     value={SortType.DISTANCE}
                     onChange={()=>{}}
                     checked={sortType === SortType.DISTANCE ? `checked` : ``}
              />
              <label
                onMouseDown = {handleSortChange}
                className="sort__btn"
                htmlFor={`sort-${SortType.DISTANCE}`}
                id={SortType.DISTANCE}
              >
                По расстоянию
              </label>
            </div>
          </div>
      )
    }
    else {
      return (<React.Fragment/>)
    }
  }
}

export default Sort;
