import React, {PureComponent} from 'react';
import MenuCity from './menu-city.jsx';
import Cinemas from './cinemas.jsx';
import Sort from './sort.jsx';
import api from '../server/api';
import SortType from '../utils.js';

class ContentContainer extends PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      cities: [],
      cinemas: [],
      selectedCityId: ``,
      sortType: SortType.TITLE
    };

    this.handleMouseDown = this.handleMouseDown.bind(this);
    this.handleSelectChange = this.handleSelectChange.bind(this);
    this.handleSortChange = this.handleSortChange.bind(this);
    this._getCinemas = this._getCinemas.bind(this);
  }

  handleMouseDown(evt) {
    this.setCities(this.props);
    evt.stopPropagation();
  }

  handleSelectChange() {
    const selectedCityId = this.refs.menuCity.state.cityId;

    if (!selectedCityId || this.selectedCityId === selectedCityId) {
      return;
    }

    this.selectedCityId = selectedCityId;
    this._getCinemas(selectedCityId, this.state.sortType);
  }

  handleSortChange(evt) {
    this.setState({
      sortType: evt.target.id
    });
    if (evt.target.id === SortType.DISTANCE) {
      this._getGeoPosition();
    }

    this._getCinemas(this.state.selectedCityId, evt.target.id);
    evt.stopPropagation();
  }

  setCities(data) {
    const cities = this._transformData(data);
    this.setState({
      cities
    });
  }

  setCinemas(cinemas, cityId) {
    this.setState({
      cinemas,
      selectedCityId: cityId,
    });
  }

  render() {
    return (
      <React.Fragment>
        <MenuCity
          ref="menuCity"
          handleSelectChange={this.handleSelectChange}
          handleMouseDown={this.handleMouseDown}
          cities={this.state.cities}
        />

        <Sort
          sortType={this.state.sortType}
          isSelectedCIty={this.state.selectedCityId ? true : false}
          handleSortChange={this.handleSortChange}
        />

        {this.state.cinemas.length > 0
          ? <Cinemas
              cinemas={this.state.cinemas}
          />
          : ``}
      </React.Fragment>
    )
  }

  _getCinemas(cityId, sortType = SortType.TITLE) {
    let parameters = `sort=${sortType}`;

    if (sortType === SortType.DISTANCE) {
      parameters += `&latitude=${this.latitude}&longitude=${this.longitude}`;
    }

    api.get(`cinemas?city=${cityId}&${parameters}`)
      .then(res => {
        this.cinemas = this._transformData(res.data.data);
        this.setCinemas(this.cinemas, cityId);
      })
  }

  _getGeoPosition() {
    const geoOptions = {
      timeout: 5000
    };

    const getGeoResult = (position) => {
      this.latitude = `` + position.coords.latitude;
      this.longitude = `` + position.coords.longitude;
    };

    const error = () => {
      console.warn(`Don't found your location`);
    };

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(getGeoResult, error, geoOptions);
    }
  }


  _transformData(data) {
    let newData = [];

    for (let key in data) {
      newData.push(data[key])
    }

    return newData;
  }
}

export default ContentContainer;
