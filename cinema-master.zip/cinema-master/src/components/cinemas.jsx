import React, {Component} from 'react';
import Cinema from './cinema.jsx';

class Cinemas extends Component {
  constructor(props) {
    super(props);
  }
  render() {
    const {cinemas} = this.props;

    return (
      <div className="cinemas">
        {cinemas.map((cinema) => <Cinema key={cinema.id} {...cinema}/>)}
      </div>
    )
  }
}

export default Cinemas;
