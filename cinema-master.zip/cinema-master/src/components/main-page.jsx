import React, {Component} from 'react';
import ContentContainer from './content-container.jsx';

class MainPage extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div className="main-page">
        <header className="main-page__head">
          <div className="logo">
            <a href="#" className="logo__link">
              <span className="logo__link-text logo__link-text--1">W</span>
              <span className="logo__link-text logo__link-text--2">M</span>
              <span className="logo__link-text logo__link-text--3">C</span>
              <span className="logo__link-text logo__link-text--4">?</span>
            </a>
          </div>
        </header>
        <div className="main-page__content">
          <ContentContainer
            {...this.props}
          />
        </div>
        <footer className="main-page__footer">
          <div className="logo">
            <a href="#" className="logo__link logo__link--light">
              <span className="logo__link-text logo__link-text--1">W</span>
              <span className="logo__link-text logo__link-text--2">M</span>
              <span className="logo__link-text logo__link-text--3">C</span>
              <span className="logo__link-text logo__link-text--4">?</span>
            </a>
          </div>

          <div className="main-page__footer-copyright">
            <p>© 2019 Where is My Cinema?</p>
          </div>
        </footer>
      </div>
    );
  }
}

export default MainPage;
