import React, {Component} from 'react';
import api from '../server/api';
import MainPage from './main-page.jsx';

class App extends Component {
  constructor(props) {
    super(props);

    this.state = {
      cities: []
    };
  }

  componentDidMount() {
    this._asyncRequest = api.get(`/cities`)
      .then(res => {
        this._asyncRequest = null;

        this.setState({
          cities: res.data.data
        });
      })
      .catch(e => console.log(e))

  }
  componentWillUnmount() {
    if (this._asyncRequest) {
      this._asyncRequest.cancel();
    }
  }

  render() {
    return (
      <MainPage {...this.state.cities}/>
    )
  }
}

export default App;
