import axios from 'axios';

const api = axios.create({
  baseURL: `https://api.kinohod.ru/api/restful/v1/`,
  timeout: 1000 * 5,
  withCredentials: false,
});

export default api;
